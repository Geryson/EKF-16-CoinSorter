# S6D0154X-Display-Driver
24 inch samsug s6D0154x driver
The display can be purchased from a few places.
I purchased the display from http://www.aliexpress.com/snapshot/6482008300.html?orderId=65678906846588

Download the repository using the download zip.
Then find you Arduino/libraries folder 
Place the unzipped Adafruit_GFX folder in the libraries folder.
Place the unzipped TouchScreen folder in the libraries folder.
Place the unzipped TFTLCD-Library-master in the libraries folder.


Open the Arduino software and select file -> examples -> TFTLCD-Library-master -> graphicstest
This will run through a selection of graphical displays

Try the other examples to get an idea of how the display works.

tf paint is a fun sketch, this one lets you draw on the display
I have made some corrections to the Sketch pin allocation enabling the touch part of the sketch to work correctly.

